﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
                //one dimenstion array
            string[] cars = { "volvo", "BMW", "ford", "mazda" };
            foreach (string val in cars)
            {
                Console.WriteLine(val);
            }
            //multi dime..
            string[,] bikes=new string[2,2]
            {
                    "
            }
        }
    }
}
