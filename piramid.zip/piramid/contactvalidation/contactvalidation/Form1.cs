﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace contactvalidation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            CheckNumber(sender, e);
        }
        private void CheckNumber(object sender, KeyPressEventArgs e)
        {
           if(! char.IsDigit(e.KeyChar) && ! char.IsControl(e.KeyChar)&& !(e.KeyChar=='.'))
            {
                    e.Handled=true;
            }
            if(e.KeyChar=='.'&&(sender as TextBox).Text.IndexOf(',')>-1)
            {
                e.Handled = true;    
            }
        }
         private void CheckNumber(object sender,KeyPressEventArgs e)
         {
             if(!char.IsDigit(e.keyChar)&& ! Char.IsDigit Control(e.keychar))
             {
                    
             }
         }
        
        
